/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phone;

/**
 *
 * @author lindy
 */
public class EncapsSimpleImplementation {
    
    public static void Data(){
        EncapsMain encapsmain = new EncapsMain();
       
        encapsmain.setName("Lindy");
        encapsmain.setUsername("Cromwel");
        encapsmain.setPassword("train");
        encapsmain.setLastname("Iminza");
        
    
            }
}
